# ZTE Config Assistant — projeto inicial

Projeto Android Kotlin para ZTE ZXHN F6201B / firmware 9.3.

Inclui captura de foto pela câmera, seleção da galeria, leitura de QR Code Wi-Fi padrão e OCR básico de etiqueta; formulário de rede 2.4/5 GHz, administrador, PPPoE, VLAN, Mesh e gerenciamento remoto; solicitação de conexão pelo `WifiNetworkSpecifier` no Android 10+ (sem Bluetooth e sem descoberta de dispositivos); salvamento local dos campos; workflow GitHub Actions para compilar APK debug.

**Limitação importante:** o botão ENVIAR CONFIGURAÇÃO ainda não altera o roteador. É necessário identificar e validar endpoints, autenticação, tokens CSRF e parâmetros do firmware 9.3. O app avisa isso em vez de simular sucesso. As credenciais ficam em preferências privadas não criptografadas nesta versão inicial; não use senhas reais até implementarmos armazenamento protegido por Android Keystore.

## Compilar
Abra a pasta no Android Studio com JDK 17 e Android SDK 35. Ou envie o projeto a um GitHub e execute a ação Build Android APK. Saída: `app/build/outputs/apk/debug/app-debug.apk`.
