package com.jackson.zteconfigassistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.*
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainActivity : ComponentActivity() {
    private lateinit var root: LinearLayout
    private val fields = linkedMapOf<String, EditText>()
    private var status: TextView? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var connectedNetwork: Network? = null

    private val camera = registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
        if (bmp != null) analyzeBitmap(bmp) else say("Captura cancelada.")
    }
    private val gallery = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) try { analyzeImage(InputImage.fromFilePath(this, uri)) } catch (_: Exception) { say("Não consegui abrir essa imagem.") }
    }
    private val wifiPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted || Build.VERSION.SDK_INT < 33) connectWifi() else say("Permissão de Wi-Fi próximo negada. Libere nas configurações do Android.")
    }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildScreen(); loadSaved() }

    private fun buildScreen() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 20, 22, 28); setBackgroundColor(0xFF10131A.toInt()) }
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
        text("ZTE CONFIG ASSISTANT", 24, 0xFFFFFFFF.toInt(), true)
        text("ZXHN F6201B • Firmware 9.3", 14, 0xFF9AA7B8.toInt())
        text("1. LER ETIQUETA / QR CODE", 17, 0xFF70D6C5.toInt(), true)
        button("ABRIR CÂMERA", 0xFF225E58.toInt()) { camera.launch(null) }
        button("ESCOLHER FOTO DA GALERIA", 0xFF263447.toInt()) { gallery.launch("image/*") }
        text("2. CONEXÃO WI-FI", 17, 0xFF70D6C5.toInt(), true)
        field("Nome da rede Wi-Fi do roteador", "wifiSsid"); field("Senha do Wi-Fi", "wifiPassword", true)
        button("CONECTAR AO WI-FI DO ZTE", 0xFF225E58.toInt()) { requestWifiPermissionAndConnect() }
        text("3. CONFIGURAÇÃO DO ROTEADOR", 17, 0xFF70D6C5.toInt(), true)
        field("Endereço do roteador", "routerAddress"); field("Usuário administrador", "adminUser"); field("Senha administrador", "adminPassword", true)
        field("SSID 2.4 GHz", "ssid24"); field("Senha 2.4 GHz", "pass24", true)
        field("SSID 5 GHz (o app acrescenta 5ghz)", "ssid5"); field("Senha 5 GHz", "pass5", true)
        field("Usuário PPPoE", "pppoeUser"); field("Senha PPPoE", "pppoePassword", true)
        field("VLAN ID (opcional)", "vlanId"); field("Prioridade VLAN (padrão 0)", "vlanPriority")
        val mesh = check("Ativar Mesh", true); check("Gerenciamento remoto IPv4", true); check("Gerenciamento remoto IPv6", true)
        check("HTTP", true); check("HTTPS", true); field("Porta de gerenciamento remoto", "remotePort")
        button("SALVAR DADOS NO CELULAR", 0xFF263447.toInt()) { saveAll(); say("Dados salvos neste aparelho.") }
        button("ENVIAR CONFIGURAÇÃO", 0xFF8A4B27.toInt()) {
            saveAll()
            say("Ainda não enviado: precisamos identificar e validar a API e autenticação do firmware 9.3 antes de alterar o roteador.")
        }
        status = TextView(this).apply { setTextColor(0xFFFFD18A.toInt()); textSize = 14f; setPadding(0, 18, 0, 10); text = "Status: aguardando conexão." }
        root.addView(status)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) {
        root.addView(TextView(this).apply { text = value; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, 1); setPadding(0, 12, 0, 5) })
    }
    private fun button(label: String, color: Int, action: () -> Unit) {
        root.addView(Button(this).apply { text = label; setTextColor(-1); setBackgroundColor(color); setOnClickListener { action() }; layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 8 } })
    }
    private fun field(label: String, key: String, password: Boolean = false) {
        val e = EditText(this).apply {
            hint = label; setHintTextColor(0xFF9AA7B8.toInt()); setTextColor(-1); textSize = 15f; setSingleLine(true)
            inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT
            setPadding(12, 8, 12, 8); setBackgroundColor(0xFF202733.toInt())
        }
        fields[key] = e; root.addView(e, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 7 })
    }
    private fun check(label: String, default: Boolean): CheckBox = CheckBox(this).apply { text = label; isChecked = default; setTextColor(-1); root.addView(this) }
    private fun say(message: String) { status?.text = "Status: $message" }

    private fun requestWifiPermissionAndConnect() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED)
            wifiPermission.launch(Manifest.permission.NEARBY_WIFI_DEVICES)
        else connectWifi()
    }
    private fun connectWifi() {
        if (Build.VERSION.SDK_INT < 29) { say("Android antigo: conecte manualmente em Configurações > Wi-Fi."); startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)); return }
        val ssid = value("wifiSsid"); val pass = value("wifiPassword")
        if (ssid.isBlank() || pass.isBlank()) { say("Informe o nome e a senha da rede."); return }
        val spec = try { WifiNetworkSpecifier.Builder().setSsid(ssid).setWpa2Passphrase(pass).build() }
            catch (_: Exception) { say("Não foi possível preparar a conexão. Confira a senha e o tipo de segurança."); return }
        val request = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(spec).build()
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        networkCallback?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                connectedNetwork = network; cm.bindProcessToNetwork(network)
                runOnUiThread { say("Conectado à rede $ssid. O Android confirmou a conexão.") }
            }
            override fun onUnavailable() { runOnUiThread { say("Não conectou. Confira SSID/senha e aceite a janela de conexão do Android.") } }
            override fun onLost(network: Network) { if (connectedNetwork == network) connectedNetwork = null; runOnUiThread { say("A conexão Wi-Fi foi encerrada.") } }
        }
        networkCallback = cb
        try { cm.requestNetwork(request, cb); say("Aguardando a confirmação do Android. Aceite a solicitação de conexão Wi-Fi.") }
        catch (e: Exception) { say("Falha ao solicitar Wi-Fi: ${e.localizedMessage ?: "erro do Android"}") }
    }

    private fun analyzeBitmap(bitmap: Bitmap) { try { analyzeImage(InputImage.fromBitmap(bitmap, 0)) } catch (_: Exception) { say("Não foi possível analisar a foto.") } }
    private fun analyzeImage(image: InputImage) {
        say("Lendo imagem…")
        val scanner = BarcodeScanning.getClient(); val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        scanner.process(image).addOnSuccessListener { codes ->
            val raw = codes.firstOrNull()?.rawValue
            if (!raw.isNullOrBlank()) { parseWifiQr(raw); say("QR Code lido. Confira os campos.") }
            else recognizer.process(image).addOnSuccessListener { parseLabelText(it.text); say("Texto reconhecido. Confira os campos.") }
                .addOnFailureListener { say("Não consegui reconhecer o texto da etiqueta.") }
        }.addOnFailureListener {
            recognizer.process(image).addOnSuccessListener { parseLabelText(it.text); say("Texto reconhecido. Confira os campos.") }
                .addOnFailureListener { say("Falha ao ler a imagem.") }
        }
    }
    private fun parseWifiQr(raw: String) {
        if (!raw.startsWith("WIFI:", true)) { parseLabelText(raw); return }
        val values = mutableMapOf<String, String>()
        raw.removePrefix("WIFI:").split(';').forEach { part -> val i = part.indexOf(':'); if (i > 0) values[part.substring(0, i)] = part.substring(i + 1) }
        values["S"]?.let { put("wifiSsid", it) }; values["P"]?.let { put("wifiPassword", it) }
    }
    private fun parseLabelText(raw: String) {
        Regex("(?im)(?:SSID|Wi-?Fi(?:\\s+Name)?)\\s*[:= ]\\s*([^\\r\\n]+)").find(raw)?.groupValues?.get(1)?.trim()?.let { put("wifiSsid", it) }
        Regex("(?im)(?:WLAN\\s+Key|Wi-?Fi\\s+Password|Password|Senha)\\s*[:= ]\\s*([^\\r\\n]+)").find(raw)?.groupValues?.get(1)?.trim()?.let { put("wifiPassword", it) }
        Regex("(?im)(?:IP|Gateway|Router)\\s*(?:Address)?\\s*[:= ]\\s*((?:\\d{1,3}\\.){3}\\d{1,3})").find(raw)?.groupValues?.get(1)?.trim()?.let { put("routerAddress", it) }
    }
    private fun value(key: String) = fields[key]?.text?.toString()?.trim().orEmpty()
    private fun put(key: String, value: String) { fields[key]?.setText(value) }
    private fun saveAll() {
        val p = getSharedPreferences("router_settings", MODE_PRIVATE).edit()
        fields.forEach { (key, edit) -> p.putString(key, edit.text.toString()) }
        p.apply()
    }
    private fun loadSaved() {
        val p = getSharedPreferences("router_settings", MODE_PRIVATE)
        fields.forEach { (key, edit) -> edit.setText(p.getString(key, when (key) { "routerAddress" -> "192.168.1.1"; "vlanPriority" -> "0"; "remotePort" -> "8081"; else -> "" })) }
    }
    override fun onDestroy() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        networkCallback?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
        cm.bindProcessToNetwork(null); super.onDestroy()
    }
}
